const http = require('http');
class MyAxios {
    timeOut = 5000;
    #hostname = '';
    #port = 80;
    #methods = {
        'POST': 'POST', 
        'PUT': 'PUT', 
        'PATCH': 'PATCH',
        'GET': 'GET',
        'DELETE': 'DELETE'
    }
    #headers = {};
    constructor(options) {
        const {
            baseUrl,
            headers
        } = options;
        const { hostname, port } = this.#separateHostnameAndPort(baseUrl);
        this.#hostname = hostname;
        this.#port = port;
        this.#headers = headers
    }
    #separateHostnameAndPort(baseUrl) {
        // Parse the base URL
        const parsedUrl = new URL(baseUrl);
    
        // Extract hostname and port
        const hostname = parsedUrl.hostname;
        const port = parsedUrl.port || (parsedUrl.protocol === 'https:' ? 443 : 80); // Default ports for HTTP and HTTPS
    
        return { hostname, port };
    }
    #logic = (endPoint, body, method) => {
        return new Promise((resolve, reject) => {
            const options = {
                hostname: this.#hostname,
                port: this.#port,
                path: endPoint,
                method: method,
                headers: {
                    ...this.#headers,
                    'Content-Length': Buffer.byteLength(JSON.stringify(body)),
                }
            };

            const req = http.request(options, (res) => {
                res.setEncoding('utf8');
                let data = '';
                res.on('data', (chunk) => {
                    data += chunk;
                });
                res.on('end', () => {
                    res['data'] = JSON.parse(data);
                    resolve(res);
                });                
            })
    
            req.on('error', (err) => {
                reject(err)
            });
            if (method == this.#methods.PATCH || method == this.#methods.POST || method == this.#methods.PUT) {
                req.write(JSON.stringify(body));
            }
            req.end();
            const timeout = setTimeout(() => {
                req.destroy();
                reject(new Error('Request timed out'));
            }, this.timeOut);

            req.on('response', () => {
                clearTimeout(timeout);
            });
        })
    }

    post(endPoint, body) {
        return this.#logic(endPoint, body, this.#methods.POST);
    }
    put(endPoint, body) {
        return this.#logic(endPoint, body, this.#methods.PUT)
    }
    patch(endPoint, body) {
        return this.#logic(endPoint, body, this.#methods.PATCH);
    }
    get(endPoint) {
        return this.#logic(endPoint, {}, this.#methods.GET)
    }
    delete(endPoint) {
        return this.#logic(endPoint, {}, this.#methods.DELETE)
    }
}

const myAxios = new MyAxios({
    baseUrl: "http://localhost:3000",
    headers:  {
        'Content-Type': 'application/json',
    },
});


myAxios.post("/", {
    name: "Abubakir",
    age: 24
}).then((res) => {
    console.log(res)
})

module.exports = MyAxios;