const net = require('net');

const server = net.createServer();

let connections = [];

server.on('connection', (socket) => {
    for (const item of connections) {
        item.pipe(socket);
        socket.pipe(item);
    }
    connections.push(socket)
})

server.listen(3000, () => {
    console.log("Listining 3000 port!")
})