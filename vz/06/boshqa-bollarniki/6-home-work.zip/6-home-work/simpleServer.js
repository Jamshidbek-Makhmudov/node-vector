const http = require('http');


const server = http.createServer();

server.on("request", (req, res) => {
    console.log('Connected!');
    req.on("data", (chunk) => {
        console.log(JSON.parse(chunk.toString()))
    })
    res.writeHead(200, { 'Content-Type': 'application/json' });
    req.pipe(res);
    req.on('end', () => {
        res.end()
    })
    res.end()
    // res.end(JSON.stringify({
    //   data: 'Hello World!',
    // }));
})


server.listen(3000, () => {
    console.log("Server running on 3000!")
})