const http = require("node:http");


// node http fetch get
const options = {
  hostname: "jsonplaceholder.typicode.com",
  port: 80,
  path: "/posts",
  method: "GET",
};

const req = http.request(options, (res) => {
  let data = "";

  res.on("data", (chunk) => {
    data += chunk;
  });

  res.on("end", () => {
    console.log(JSON.parse(data));
    console.log("Get request sent successfully");
  });

});

req.on("error", (error) => {
  console.error("Error:", error);
});

req.end();



// // node http fetch post
// const postData = JSON.stringify({ id: 1, name: 'Hello world!', value: 456 });

// const options = {
//   hostname: 'jsonplaceholder.typicode.com',
//   port: 80,
//   path: '/posts',
//   method: 'POST',
//   headers: {
//     'Content-Type': 'application/json',
//     'Content-Length': postData.length
//   }
// };

// const req = http.request(options, (res) => {
//   let data = '';

//   res.on('data', (chunk) => {
//     data += chunk;
//   });

//   res.on('end', () => {
//     console.log(JSON.parse(data));
//     console.log('Delete request sent successfully');
//   });
// });

// req.on('error', (error) => {
//   console.error('Error:', error);
// });

// req.write(postData);
// req.end();




// // node.jsda http fetch put
// const updatedData = JSON.stringify({ id: 1, name: 'Hello world!', value: 456 });

// const options = {
//   hostname: 'jsonplaceholder.typicode.com',
//   port: 80,
//   path: '/posts/1',
//   method: 'PUT',
//   headers: {
//     'Content-Type': 'application/json',
//     'Content-Length': updatedData.length
//   }
// };

// const req = http.request(options, (res) => {
//   let data = '';

//   res.on('data', (chunk) => {
//     data += chunk;
//   });

//   res.on('end', () => {
//     console.log(JSON.parse(data));
//   });
// });

// req.on('error', (error) => {
//   console.error('Error:', error);
// });

// req.write(updatedData);
// req.end();



//// node http fetch delete
//  const options = {
//   hostname: 'jsonplaceholder.typicode.com',
//   port: 80,
//   path: '/posts/1',
//   method: 'DELETE'
// }

// const req = http.request(options, (res) => {
//   let data = '';

//   res.on('data', (chunk) => {
//     data += chunk;
//   });

//   res.on('end', () => {
//     console.log(JSON.parse(data));
//     console.log('Delete request sent successfully');
//   })

// })


// req.on('error', (error) => {
//   console.error('Error:', error);
// })


// req.end()
