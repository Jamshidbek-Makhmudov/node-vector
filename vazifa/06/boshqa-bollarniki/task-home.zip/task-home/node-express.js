const http = require("http");

class Express {
  constructor() {
    this.routes = {
      GET: {},
      POST: {},
      PUT: {},
      DELETE: {},
      ALL: {},
    };

    this.middlewares = [];

    this.errorHandler = (err, req, res) => {
      console.error(err);
      res.statusCode = 500;
      res.end("Internal Server Error");
    };
  }

  use(handler) {
    this.middlewares.push(handler);
  }

  get(path, handler) {
    this.routes["GET"][path] = handler;
  }

  post(path, handler) {
    this.routes["POST"][path] = handler;
  }

  put(path, handler) {
    this.routes["PUT"][path] = handler;
  }

  delete(path, handler) {
    this.routes["DELETE"][path] = handler;
  }

  all(path, handler) {
    this.routes["ALL"][path] = handler;
  }

  handleRequest(req, res) {
    const { method, url } = req;
    const routeHandler = this.routes[method][url] || this.routes["ALL"]["*"];
    let idx = 0;

    const next = () => {
      if (idx < this.middlewares.length) {
        this.middlewares[idx++](req, res, next);
      } else if (routeHandler) {
        routeHandler(req, res);
      } else {
        const notFoundError = new Error("Not Found");
        this.errorHandler(notFoundError, req, res);
      }
    };

    next();
  }

  listen(port, callback) {
    const server = http.createServer((req, res) => {
      this.handleRequest(req, res);
    });

    server.listen(port, callback);
  }
}

// Express class on top of the http module
const app = new Express();

app.use((req, res, next) => {
  console.log("Middleware runnded");
  next();
});

app.get("/", (req, res) => {
  res.end("express get sendet successfully");
});

app.post("/", (req, res) => {
  res.end("express post sendet successfully");
});

app.listen(3000, () => {
  console.log("Server on runnded on port 3000");
});
